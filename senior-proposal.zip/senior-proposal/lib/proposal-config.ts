export const proposalConfig={
 seniorName:'Senior',
 openingTitle:'Hey Senior… 👀',
 openingSubtitle:'I have something important to ask you.',
 loveQuestion:'Do you love me? 🥺',
 letterTitle:'Something I wrote for you 💌',
 loveLetter:`Dear Senior, ❤️\n\nI don't know exactly when it happened, but somewhere between our conversations, your smile, and all those little moments, you became someone very special to me.\n\nI don't want to make this complicated.\n\nI just want to say one simple thing…\n\nI Love You. ❤️\n\nI don't know what the future holds, but I would love to create some beautiful memories with you.\n\nSo, Senior…\n\nWill you be my special person? ❤️`,
 finalQuestion:'Will you be my special person?',
 celebrationMessage:'Here’s to our first date… and hopefully many more. ❤️'
};
