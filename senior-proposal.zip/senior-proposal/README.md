# Hey Senior ❤️

A mobile-first interactive proposal website built with Next.js, TypeScript, Tailwind CSS, Framer Motion and Lucide React.

## Run

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm start
```

## Customize

Edit `lib/proposal-config.ts` to change the senior's name, proposal letter, opening copy and celebration message.

Date, time and place are stored only in the browser's localStorage; there is no database or external API.

## Deploy

Push the project to GitHub and import it into Vercel, or use the Vercel CLI.
