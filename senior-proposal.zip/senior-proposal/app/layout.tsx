import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'Hey Senior ❤️',description:'A little surprise from my heart.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
